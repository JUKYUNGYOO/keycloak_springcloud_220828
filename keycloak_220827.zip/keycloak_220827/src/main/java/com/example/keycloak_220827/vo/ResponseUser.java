package com.example.keycloak_220827.vo;

import lombok.Data;

@Data
public class ResponseUser {

    private String email;
    private String name;
    private String UserId;
}
