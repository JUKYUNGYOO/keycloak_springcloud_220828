package com.example.keycloak_220827;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Keycloak220827ApplicationTests {

    @Test
    void contextLoads() {
    }

}
